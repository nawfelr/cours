<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container px-4 px-lg-5">
        <a class="navbar-brand" href="index.php">Accueil</a>
    </div>
    <div class="container px-4 px-lg-5">
        <a class="navbar-brand" href="./form_ajout_produit.php">Création Produit</a>
    </div>
    <div class="container px-4 px-lg-5">
        <a class="navbar-brand" href="./tous_les_produits.php">Tous les Produits</a>
    </div>