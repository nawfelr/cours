// Navigation avec les liens actifs sur la page en cours

// 1- Ajouter l'id #activ_nav sur la balise <nav>

// 2- verifier que la class .activ est bien sur le fichier css

// 3- créer la fonction setActiv() pour ajouter la class .activ sur le lien URL en cours