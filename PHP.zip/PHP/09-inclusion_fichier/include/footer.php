</main>
<!-- // fin de main -->


<!-- // début de footer -->
<footer>
    <!-- syntaxe boostrap pour center le texte plus un margin top de 5. Suivi d'un passage contracté php pour récupérer l'année en cours avec date() -->

    <p class="text-center mt-5">&copy; - <?= date('Y') ?> Delia </p>

</footer>
<!-- // fin du footer -->

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script>

</body>

</html>